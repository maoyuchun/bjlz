//
//  MineViewController.m
//  XXDemo
//
//  Created by Lost-souls on 2019/4/10.
//  Copyright © 2019年 Lost-souls. All rights reserved.
//

#import "MineViewController.h"
#import "MineTableViewCell.h"
#import "MineListDataModel.h"
#import "MineTableHeaderView.h"
#import "MineTableFooterView.h"
#import "UIView+Extend.h"

@interface MineViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    UIStatusBarStyle _statusBarStyle;

}
@property (nonatomic,strong) UITableView *mineTableView;

@property (nonatomic,copy) NSArray<MineListDataModel *> *mineListData;

@end

static NSString *const kCellID = @"MineTableViewCellID";

@implementation MineViewController

#pragma mark - Life Cycle

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    [self changeNavBarTransparent];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self updateSeparatorLineInset:UIEdgeInsetsZero obj:self.mineTableView];
    
    [self.view addSubview:self.mineTableView];
    self.title = @"个人中心";
    
    MineTableHeaderView *headerView = [MineTableHeaderView viewFromXIB];
    headerView.frame = CGRectMake(0, 0, self.view.width, 226.f);
    
    MineTableFooterView *footerView = [[MineTableFooterView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 150.f) action:^(id  _Nonnull obj) {
        NSLog(@"action......");
    }];
    
    self.mineTableView.tableHeaderView = headerView;
    self.mineTableView.tableFooterView = footerView;

}
- (void)viewWillLayoutSubviews{
    
    [super viewWillLayoutSubviews];
    
    self.mineTableView.frame = CGRectMake(0, -kNavStatusBarH, self.view.frame.size.width, self.view.frame.size.height+kNavStatusBarH);
    
}
- (void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:animated];
    
    [self changeNavBarDisTransparent];
    
}


- (UIStatusBarStyle)preferredStatusBarStyle{
    return _statusBarStyle;
}



#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.mineListData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
 
    MineTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellID forIndexPath:indexPath];
    cell.data = self.mineListData[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 60.f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 15.f;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [self updateSeparatorLineInset:UIEdgeInsetsZero obj:cell];
    
}

#pragma mark - Private Method
/// 导航栏透明
- (void)changeNavBarTransparent
{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    //    [self.navigationController presentTransparentNavigationBar];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    _statusBarStyle = UIStatusBarStyleLightContent;
    [self setNeedsStatusBarAppearanceUpdate];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
}
/// 恢复
- (void)changeNavBarDisTransparent
{
    [self.navigationController.navigationBar setBackgroundImage:[[UINavigationBar appearance] backgroundImageForBarMetrics:UIBarMetricsDefault] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[[UINavigationBar appearance] shadowImage]];
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor darkGrayColor]}];
    _statusBarStyle = UIStatusBarStyleDefault;
    [self setNeedsStatusBarAppearanceUpdate];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = UIColor.darkGrayColor;
}

- (void)updateSeparatorLineInset:(UIEdgeInsets)tabSeparatorInset obj:(id)obj {
    
    if ([obj respondsToSelector:@selector(setSeparatorInset:)]) {
        [obj setSeparatorInset:tabSeparatorInset];
    }
    
    if ([obj respondsToSelector:@selector(setLayoutMargins:)]) {
        [obj setLayoutMargins:tabSeparatorInset];
    }
}


#pragma mark - Getter & Setters

- (UITableView *)mineTableView{
    
    if (!_mineTableView) {
        _mineTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _mineTableView.delegate = self;
        _mineTableView.dataSource = self;
        _mineTableView.backgroundColor = UIColor.groupTableViewBackgroundColor;
        UINib *nib = [UINib nibWithNibName:NSStringFromClass([MineTableViewCell class]) bundle:nil];
        [_mineTableView registerNib:nib forCellReuseIdentifier:kCellID];
    }
    return _mineTableView;
}


- (NSArray<MineListDataModel *> *)mineListData{
    
    if (!_mineListData) {
        NSArray<NSString *> *titles = @[@"意见反馈",@"匹配订单",@"设置支付密码",@"实名认证"];
        NSArray<NSString *> *subtitles = @[@"",@"",@"未设置支付密码",@"未实名认证"];
        NSMutableArray<MineListDataModel *> *temp = @[].mutableCopy;
        for (int i=0; i<titles.count; i++) {
            MineListDataModel *model = [MineListDataModel new];
            model.iconName = [NSString stringWithFormat:@"mine_list_%d",i];
            model.title = titles[i];
            model.statusText = subtitles[i];
            [temp addObject:model];
        }
        _mineListData = temp.copy;
    }
    return _mineListData;
}

@end
