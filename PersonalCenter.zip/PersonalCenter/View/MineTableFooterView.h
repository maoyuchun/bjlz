//
//  MineTableFooterView.h
//  XXDemo
//
//  Created by Lost-souls on 2019/4/10.
//  Copyright © 2019年 Lost-souls. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 回调
typedef void(^MineTableFooterViewBtnAction)(id obj);

@interface MineTableFooterView : UIView

- (instancetype)initWithFrame:(CGRect)frame action:(MineTableFooterViewBtnAction)action;

@end

NS_ASSUME_NONNULL_END
