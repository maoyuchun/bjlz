//
//  MineTableViewCell.m
//  XXDemo
//
//  Created by Lost-souls on 2019/4/10.
//  Copyright © 2019年 Lost-souls. All rights reserved.
//


#import "MineTableViewCell.h"
#import "UIFont+MYCAdd.h"
#import "MJRefresh.h"
#import "MineListDataModel.h"

@interface MineTableViewCell ()
@property (weak, nonatomic) IBOutlet UIImageView *iconImgv;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UIImageView *allowImgv;

@end

@implementation MineTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];

    
    
}





- (void)layoutSubviews{
    
    [super layoutSubviews];
    
}

- (void)setData:(MineListDataModel *)data{
    
    _data = data;
    
    self.iconImgv.image = [UIImage imageNamed:data.iconName];
    self.titleLabel.text = data.title;
    self.statusLabel.text = data.statusText;
    
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


@end
