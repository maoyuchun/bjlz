//
//  MineTableFooterView.m
//  XXDemo
//
//  Created by Lost-souls on 2019/4/10.
//  Copyright © 2019年 Lost-souls. All rights reserved.
//

#import "MineTableFooterView.h"
#import "UIFont+MYCAdd.h"
#import "UIImage+Gradient.h"
#import "PreFixHeader.h"

@interface MineTableFooterView ()

@property (nonatomic,strong) UIButton *logoutButton;
@property (nonatomic,copy) MineTableFooterViewBtnAction mAction;
@end

@implementation MineTableFooterView

- (instancetype)initWithFrame:(CGRect)frame action:(MineTableFooterViewBtnAction)action{
    
    if (self = [super initWithFrame:frame]) {
        
        [self addSubview:self.logoutButton];
        if (action) {
            self.mAction = action;
        }
        self.backgroundColor = UIColor.groupTableViewBackgroundColor;
    }
    return self;
}

- (void)layoutSubviews{
    
    [super layoutSubviews];
    
    self.logoutButton.frame = CGRectMake((self.frame.size.width-325.f)/2.f, 75.f, 325.f, 50.f);
    
}

- (void)logoutAction:(UIButton *)btn{
    
    if (self.mAction) {
        self.mAction(btn);
    }
    
}

- (UIButton *)logoutButton{
    if (!_logoutButton) {
        _logoutButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [_logoutButton setTitle:@"退出登录" forState:UIControlStateNormal];
        _logoutButton.titleLabel.font = [UIFont PFSCMediumWithSize:18.f];
        [_logoutButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        UIImage *tpimg = [[UIImage alloc]createImageWithSize:CGSizeMake(325, 50) gradientColors:@[hexCOLOR(@"ff896f"),hexCOLOR(@"ff5d51")] percentage:@[@(0.2),@(1)] gradientType:GradientFromLeftToRight];
        
        [_logoutButton setBackgroundImage:tpimg forState:UIControlStateNormal];
        _logoutButton.backgroundColor = UIColor.orangeColor;
        _logoutButton.layer.cornerRadius = 25.f;
        _logoutButton.layer.masksToBounds = YES;
        [_logoutButton addTarget:self action:@selector(logoutAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return  _logoutButton;
}

@end
