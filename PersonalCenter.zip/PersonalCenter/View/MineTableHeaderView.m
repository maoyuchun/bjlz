//
//  MineTableHeaderView.m
//  XXDemo
//
//  Created by Lost-souls on 2019/4/10.
//  Copyright © 2019年 Lost-souls. All rights reserved.
//

#import "MineTableHeaderView.h"
#import "UIImage+Gradient.h"
#import "PreFixHeader.h"

@interface MineTableHeaderView ()
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;

@end

@implementation MineTableHeaderView

- (void)awakeFromNib {
    [super awakeFromNib];
    
    UIImage *tpimg = [[UIImage alloc]createImageWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width, 226.f) gradientColors:@[hexCOLOR(@"ff896f"),hexCOLOR(@"ff5d51")] percentage:@[@(0.2),@(1)] gradientType:GradientFromLeftToRight];
    
    self.bgImageView.image = tpimg;
    
}


- (void)setFrame:(CGRect)frame{
    
    CGRect rect = CGRectMake(0, 0, kScreenW, 226.f);
    
    [super setFrame:rect];
    
}
@end
