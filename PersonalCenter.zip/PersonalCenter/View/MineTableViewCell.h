//
//  MineTableViewCell.h
//  XXDemo
//
//  Created by Lost-souls on 2019/4/10.
//  Copyright © 2019年 Lost-souls. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class MineListDataModel;
@interface MineTableViewCell : UITableViewCell

@property (nonatomic,strong) MineListDataModel *data;

@end


NS_ASSUME_NONNULL_END
