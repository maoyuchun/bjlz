//
//  MineListDataModel.m
//  XXDemo
//
//  Created by Lost-souls on 2019/4/10.
//  Copyright © 2019年 Lost-souls. All rights reserved.
//

#import "MineListDataModel.h"

@implementation MineListDataModel

@end
