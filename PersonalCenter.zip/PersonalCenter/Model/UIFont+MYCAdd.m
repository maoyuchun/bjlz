//
//  UIFont+MYCAdd.m
//  XXDemo
//
//  Created by Lost-souls on 2019/4/10.
//  Copyright © 2019年 Lost-souls. All rights reserved.
//

#import "UIFont+MYCAdd.h"

@implementation UIFont (MYCAdd)


+ (UIFont *)PFSCBlodWithSize:(CGFloat)fontSize{
    
    UIFont *font = [UIFont fontWithName:@"PingFangSC-Semibold" size:fontSize];
    if (font == nil) {
        font = [UIFont boldSystemFontOfSize:fontSize];
    }
    return font;
}

+ (UIFont *)PFSCMediumWithSize:(CGFloat)fontSize{
    
    UIFont *font = [UIFont fontWithName:@"PingFangSC-Medium" size:fontSize];
    if (font == nil) {
        font = [UIFont systemFontOfSize:fontSize];
    }
    return font;
}

+ (UIFont *)PFSCRegularWithSize:(CGFloat)fontSize{
    
    UIFont *font = [UIFont fontWithName:@"PingFangSC-Regular" size:fontSize];
    if (font == nil) {
        font = [UIFont systemFontOfSize:fontSize];
    }
    return font;
}

@end
