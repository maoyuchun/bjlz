//
//  MineListDataModel.h
//  XXDemo
//
//  Created by Lost-souls on 2019/4/10.
//  Copyright © 2019年 Lost-souls. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MineListDataModel : NSObject

@property (nonatomic,strong) NSString *iconName;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *statusText;


@end

NS_ASSUME_NONNULL_END
